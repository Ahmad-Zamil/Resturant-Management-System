$table_no<!-- ############################## Header Section ############################## -->
<?php include("header.php"); ?>


<!-- ############################## Right Side Menue Section ############################## -->
<?php include("side-menue.php");
$table_no=9;
?>

<?php

                            $sql = "SELECT * FROM orders where ((table_no='$table_no')&&(status='Order_Placed')) ORDER BY id ASC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                // output data of each row
                                $key=1;
                                }else{
                                    $key=0;
                                }?>

<div class="row">
    <div class="col-12">

<?php if($key==1){?>
    <div class="card">
            <div class="card-header">
                <h4>Your Order List</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th class="p-0 text-center">Name</th>
                            <th>price</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        


                            <?php

                            $sql = "SELECT * FROM orders where ((table_no='$table_no')&&(status='Order_Placed')) ORDER BY id ASC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {

                            ?> <tr>
                                <td class="p-0 text-center"><?php echo $row['name'] ?></td>
                                                                <td>
                                        <div class=""><?php echo $row['p_price'] ?></div>
                                    </td>
                                    <td>
                                    <?php echo $row['quantiry'] ?>
                                    </td>
                                    <td> <div class="badge badge-success"><?php echo $row['status'] ?></div></td>
                                    
                                    <td><a href="#" class="btn btn-primary">Detail</a></td>
                        </tr>
                            <?php }
                            } ?>

                    </table>
                </div>
            </div>
        </div>
<?php }?>


        <div class="card">
            <div class="card-header">
                <h4>Our Food Items</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th class="p-0 text-center">Name</th>
                            <th>price</th>
                            <th></th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <tr>


                            <?php

                            $sql = "SELECT * FROM food_item ORDER BY id ASC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {

                            ?> <td class="p-0 text-center"><?php echo $row['name'] ?></td>
                                                                <td>
                                        <div class=""><?php echo $row['price'] ?></div>
                                    </td>
                                    <td>
                                        <img alt="image" src="assets/image/<?php echo $row['image'] ?>" class="rounded-circle" width="35" data-toggle="tooltip" title="Wildan Ahdian">
                                    </td>
                                    
                                    <td>
                                        <div class="badge badge-success"><?php echo $row['status'] ?></div>
                                    </td>
                                    <td><a href="order_store.php?id=<?php echo $row['id']?>&&from=index.php&&table_no=<?php echo $table_no?>" class="btn btn-primary">Order Now</a></td>
                        </tr>
                            <?php }
                            } ?>

                    </table>
                </div>
            </div>
        </div>




      
    </div>
</div>




<!-- ############################## Footer Section ############################## -->
<?php include("footer.php"); ?>