</div>



<footer class="main-footer">

    <div class="copyright_text text-center">

        <p>

            Copyright ©

            <script>
                document.write(new Date().getFullYear());
            </script>

            All rights reserved | Developed by <a href="https://www.srsoftbd.xyz/" target="_blank">SR Soft BD</a>

        </p>

    </div>

</footer>



</div>

</div>



<!-- General JS Scripts -->
<script src="assets/js/app.min.js"></script>


<!-- JS Libraies -->
<script src="assets/bundles/apexcharts/apexcharts.min.js"></script>
<script src="assets/bundles/datatables/datatables.min.js"></script>
<script src="assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
<script src="assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
<script src="assets/bundles/datatables/export-tables/jszip.min.js"></script>
<script src="assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
<script src="assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
<script src="assets/bundles/datatables/export-tables/buttons.print.min.js"></script>
<script src="assets/bundles/summernote/summernote-bs4.js"></script>
<script src="assets/bundles/codemirror/lib/codemirror.js"></script>
<script src="assets/bundles/codemirror/mode/javascript/javascript.js"></script>
<script src="assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
<script src="assets/bundles/ckeditor/ckeditor.js"></script>

  <!-- JS Libraies -->
  <script src="assets/bundles/sweetalert/sweetalert.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/sweetalert.js"></script>




<!-- Page Specific JS File -->
<script src="assets/js/page/index.js"></script>
<script src="assets/js/page/datatables.js"></script>
<script src="assets/js/page/ckeditor.js"></script>


<!-- Template JS File -->
<script src="assets/js/scripts.js"></script>


<!-- Custom JS File -->
<script src="assets/js/custom.js"></script>


</body>

</html>